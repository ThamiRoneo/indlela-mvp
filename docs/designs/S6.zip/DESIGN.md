---
name: Indlela Transit & Commute
colors:
  surface: '#faf9fd'
  surface-dim: '#dbd9dd'
  surface-bright: '#faf9fd'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f4f3f7'
  surface-container: '#efedf1'
  surface-container-high: '#e9e7eb'
  surface-container-highest: '#e3e2e6'
  on-surface: '#1a1b1e'
  on-surface-variant: '#414754'
  inverse-surface: '#2f3033'
  inverse-on-surface: '#f1f0f4'
  outline: '#727785'
  outline-variant: '#c1c6d6'
  surface-tint: '#005bc0'
  primary: '#005bbf'
  on-primary: '#ffffff'
  primary-container: '#1a73e8'
  on-primary-container: '#ffffff'
  inverse-primary: '#adc7ff'
  secondary: '#006e2c'
  on-secondary: '#ffffff'
  secondary-container: '#86f898'
  on-secondary-container: '#00722f'
  tertiary: '#795900'
  on-tertiary: '#ffffff'
  tertiary-container: '#987000'
  on-tertiary-container: '#ffffff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#d8e2ff'
  primary-fixed-dim: '#adc7ff'
  on-primary-fixed: '#001a41'
  on-primary-fixed-variant: '#004493'
  secondary-fixed: '#89fa9b'
  secondary-fixed-dim: '#6ddd81'
  on-secondary-fixed: '#002108'
  on-secondary-fixed-variant: '#005320'
  tertiary-fixed: '#ffdfa0'
  tertiary-fixed-dim: '#fbbc05'
  on-tertiary-fixed: '#261a00'
  on-tertiary-fixed-variant: '#5c4300'
  background: '#faf9fd'
  on-background: '#1a1b1e'
  surface-variant: '#e3e2e6'
typography:
  headline-lg:
    fontFamily: Roboto Flex
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Roboto Flex
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Roboto Flex
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: 0em
  title-md:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '600'
    lineHeight: 22px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Roboto Flex
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-md:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.015em
  body-sm:
    fontFamily: Roboto Flex
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-lg:
    fontFamily: Roboto Flex
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-md:
    fontFamily: Roboto Flex
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.03em
  label-sm:
    fontFamily: Roboto Flex
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 0.75rem
  margin: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1rem
  space-xl: 1.5rem
---

## Brand & Style
The design system serves everyday South African commuters navigating multi-modal transit (minibus taxis, Metrorail, Rea Vaya, Golden Arrow, and walking routes) alongside time-sensitive job commutes. The core emotional tone is dependable, clear, and reassuring under high-stress conditions such as low battery, bright sunlight, or fluctuating edge-network connectivity.

The design movement combines **Corporate / Modern (Android Material 3 foundations)** with **functional utility minimalism**. Visual noise, decorative flourishes, and heavy graphical assets are eliminated to ensure lightning-fast rendering on budget devices, high legibility on screens outdoors, and immediate glanceability for route transfers and schedules.

## Colors
The palette leverages standard Android accessibility roles with high-contrast ratios for rapid outdoor comprehension:

- **Primary (`#1a73e8`):** Applied to dominant interactive targets, selected navigation states, primary route indicators, and active commute progress trackers.
- **Secondary (`#34a853`):** Applied to on-time route indicators, affirmative journey confirmations, safe departure times, and fare validation states.
- **Tertiary / Warning (`#fbbc04`):** Applied to minor delays, schedule adjustments, load shedding traffic impacts, and advisory alerts. Must use `#202124` text on top to preserve accessible contrast.
- **Error (`#ea4335`):** Reserved for service cancellations, urgent route diversions, safety warnings, and form validation errors.
- **Background (`#ffffff`) & Surface (`#f8f9fa`):** Base canvas and structural card containers.
- **Border (`#dadce0`) & Disabled (`#bdc1c6`):** Low-key structural dividers and inactive tap targets.
- **Text Primary (`#202124`) & Text Secondary (`#5f6368`):** Ensures AA/AAA compliance against `#ffffff` and `#f8f9fa` surfaces across all text tiers.

## Typography
`Roboto Flex` provides reliable system metric parity on Android devices, ensuring zero font-loading latency and predictable glyph rendering across screen densities. 

Scale characteristics:
- Headlines cap at `28px` to guarantee multi-line terminal names (e.g., "Johannesburg Park Station") fit within 360px viewport widths without truncation or awkward line breaking.
- Numeric wayfinding, times, and fare prices (`R18.50`) default to `label-lg` or `headline-sm` with tabular alignment where applicable.
- Letter spacing is loosened on labels and small sizes (`0.02em` - `0.04em`) to prevent character clustering on lower-resolution IPS displays.

## Layout & Spacing
Built strictly for mobile portrait viewports (`360x800px`) using an 8pt spatial grid with 4pt half-steps for compact density:

- **Screen Canvas:** Fixed horizontal padding uses `margin` (`16px / 1rem`). Internal content stays within a 328px usable track.
- **Columns & Gutters:** A 4-column fluid layout with `gutter` (`12px / 0.75rem`) handles card grids and transit segment timelines.
- **Vertical Rhythm:** 
  - `space-xs` (4px): Spacing between badge icons and microcopy.
  - `space-sm` (8px): Gaps between list title and subtitle, form inputs and helper text.
  - `space-md` (12px): Standard inner padding for compact cards, list item vertical padding.
  - `space-lg` (16px): Outer padding for surface containers, bottom sheets, and sticky action docks.
  - `space-xl` (24px): Logical section breaks between route options.

## Elevation & Depth
Given performance constraints on entry-level Android chipsets and bright outdoor glare, this system avoids complex blur shaders and deep drop shadows. Elevation is articulated through **tonal layers paired with crisp low-contrast outlines**:

- **Level 0 (Canvas Base):** Pure `#ffffff`. Flat, zero elevation.
- **Level 1 (Cards & Feed Items):** Background `#f8f9fa` framed with a 1px solid border of `#dadce0`. No shadow.
- **Level 2 (Active Sheets & Modals):** Surface `#ffffff`, 1px border `#dadce0`, supported by a direct low-spread ambient shadow: `0px 2px 6px rgba(32, 33, 36, 0.08)`.
- **Level 3 (Sticky Bottom Navigation & Floating Commute Bar):** Surface `#ffffff` elevated above canvas with a top border of 1px `#dadce0` and an ambient rise of `0px -2px 8px rgba(32, 33, 36, 0.06)`.

## Shapes
A roundedness level of `2` (`8px / 0.5rem` baseline) establishes a modern Android feel without consuming excess screen real estate:

- **Base Radius (`rounded`, 8px):** Applied to transit cards, route option summary containers, text input fields, and alert banners.
- **Large Radius (`rounded-lg`, 16px):** Applied to top edges of interactive bottom sheets (route details, schedule tables) and persistent modal drawers.
- **Full Radius (`pill`, 9999px):** Applied exclusively to transit filter chips, transport mode pills (Train, Bus, Taxi), floating action buttons, and active status tags.

## Components

### Buttons
- **Primary Action:** Background `#1a73e8`, text `#ffffff`, font `label-lg`, height 48px (meeting Android's touch-target guidelines), corner radius 8px. Pressed state: `#1558b0`.
- **Secondary Action:** Transparent background, 1px solid `#dadce0` border, text `#1a73e8`, height 48px, radius 8px.
- **Disabled State:** Background `#bdc1c6`, text `#ffffff`, pointer events none.

### Chips (Transit Filters & Modes)
- Height 32px, pill-shaped radius (9999px).
- **Default:** Background `#f8f9fa`, border 1px solid `#dadce0`, text `#5f6368` (`label-md`), horizontal padding 12px.
- **Selected:** Background `#1a73e8`, border 1px solid `#1a73e8`, text `#ffffff`.

### Lists & Transit Timeline
- List items feature 48px minimum vertical touch targets with 12px internal vertical padding.
- Multi-leg journey nodes use vertical 2px solid lines (`#dadce0` for walking, `#1a73e8` for bus/train) anchored by 10px circular dots.
- Text uses `title-md` for station names and `body-sm` (`#5f6368`) for departure intervals.

### Form Inputs
- Height 52px, surface `#ffffff`, border 1px solid `#dadce0`, radius 8px, padding 12px 16px.
- **Focus:** 2px border `#1a73e8`.
- **Error:** 2px border `#ea4335`, paired with an error icon and caption in `body-sm` (`#ea4335`).

### Commute Route Cards
- Container uses `#f8f9fa`, 1px solid border `#dadce0`, 8px radius, 12px internal padding.
- Fare values displayed top-right using `label-lg` in `#202124`.
- Estimated travel time emphasized using `headline-sm` with delay badges tinted in `#ea4335` (cancelled) or `#34a853` (on time).

### Bottom Sheet (Route Explorer)
- Anchored to bottom edge, surface `#ffffff`, top-left and top-right radii 16px, top border 1px `#dadce0`.
- Includes a centered 32x4px handle bar (`#bdc1c6`) with 8px vertical padding for gesture drag cues.